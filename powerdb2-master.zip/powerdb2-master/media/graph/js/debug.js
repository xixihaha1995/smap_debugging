function debug(str) {
  //$("#debug").text(str + "\n" + $("#debug").text());
}

