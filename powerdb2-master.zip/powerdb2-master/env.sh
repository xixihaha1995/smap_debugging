
export PYTHONPATH=.:/Users/stevedh/src/svn/code/:/Users/stevedh/src/svn/code/smap
export DJANGO_SETTINGS_MODULE=powerdb.settings
