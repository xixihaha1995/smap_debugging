# -*- coding: utf-8 -
#
# This file is part of restkit released under the MIT license. 
# See the NOTICE for more information.

from restkit.client.response import HttpResponse
from restkit.client.request import HttpRequest, MAX_FOLLOW_REDIRECTS, USER_AGENT
