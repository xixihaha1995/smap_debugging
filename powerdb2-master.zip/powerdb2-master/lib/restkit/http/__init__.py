# -*- coding: utf-8 -
#
# This file is part of restkit released under the MIT license. 
# See the NOTICE for more information.

from restkit.http.message import Message, Request
from restkit.http.parser import RequestParser, ResponseParser
