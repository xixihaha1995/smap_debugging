
#include "../src/hashtable.h"

START_TEST(test_hashtable_create)
{
  
}
